import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Navigation() {
  const { pathname } = useLocation();

  return (
    <nav className="navigation">
      <ul>
        <li>
          <Link to="/archives" aria-current={pathname === '/archives' ? 'page' : undefined}>
            Arsip
          </Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navigation;