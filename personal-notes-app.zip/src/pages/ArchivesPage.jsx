import React from 'react';
import { useSearchParams } from 'react-router-dom';
import NoteList from '../components/NoteList';
import SearchBar from '../components/SearchBar';
import { getArchivedNotes } from '../utils/local-data';

function ArchivesPageWrapper() {
  const [searchParams, setSearchParams] = useSearchParams();
  const keyword = searchParams.get('title') || '';

  function onSearch(keywordValue) {
    if (keywordValue) {
      setSearchParams({ title: keywordValue });
    } else {
      setSearchParams({});
    }
  }

  return <ArchivesPage defaultKeyword={keyword} onSearch={onSearch} />;
}

class ArchivesPage extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      notes: getArchivedNotes()
        .filter((n) => (props.defaultKeyword ? n.title.toLowerCase().includes(props.defaultKeyword.toLowerCase()) : true))
    };

    this.onSearch = this.onSearch.bind(this);
  }

  onSearch(keyword) {
    const filtered = getArchivedNotes().filter((note) =>
      keyword ? note.title.toLowerCase().includes(keyword.toLowerCase()) : true
    );

    this.setState(() => ({ notes: filtered }));
    this.props.onSearch(keyword);
  }

  render() {
    return (
      <section className="archives-page">
        <h2>Catatan Arsip</h2>
        <SearchBar search={this.onSearch} defaultKeyword={this.props.defaultKeyword} />
        <NoteList notes={this.state.notes} emptyText="Arsip Kosong" />
      </section>
    );
  }
}

export default ArchivesPageWrapper;