import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import NoteList from '../components/NoteList';
import SearchBar from '../components/SearchBar';
import { getActiveNotes } from '../utils/local-data';

function HomePageWrapper() {
  const [searchParams, setSearchParams] = useSearchParams();
  const keyword = searchParams.get('title') || '';

  function onSearch(keywordValue) {
    if (keywordValue) {
      setSearchParams({ title: keywordValue });
    } else {
      setSearchParams({});
    }
  }

  return <HomePage defaultKeyword={keyword} onSearch={onSearch} />;
}

class HomePage extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      notes: getActiveNotes()
        .filter((n) => (props.defaultKeyword ? n.title.toLowerCase().includes(props.defaultKeyword.toLowerCase()) : true))
    };

    this.onSearch = this.onSearch.bind(this);
  }

  onSearch(keyword) {
    const filtered = getActiveNotes().filter((note) =>
      keyword ? note.title.toLowerCase().includes(keyword.toLowerCase()) : true
    );

    this.setState(() => ({ notes: filtered }));
    this.props.onSearch(keyword);
  }

  render() {
    return (
      <section className="homepage">
        <h2>Catatan Aktif</h2>
        <SearchBar search={this.onSearch} defaultKeyword={this.props.defaultKeyword} />
        <NoteList notes={this.state.notes} emptyText="Tidak ada catatan" />

        <div className="homepage__action">
          <Link className="action" to="/notes/new" title="Tambah" aria-label="Tambah">
            <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 24 24" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
              <path fill="none" d="M0 0h24v24H0z"></path>
              <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"></path>
            </svg>
          </Link>
        </div>
      </section>
    );
  }
}

export default HomePageWrapper;