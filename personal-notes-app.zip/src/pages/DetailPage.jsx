import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import NoteDetail from '../components/NoteDetail';
import NoteItemAction from '../components/NoteItemAction';
import { getNote, deleteNote, archiveNote, unarchiveNote } from '../utils/local-data';

function DetailPageWrapper() {
  const { id } = useParams();
  const navigate = useNavigate();
  return <DetailPage id={id} navigate={navigate} />;
}

class DetailPage extends React.Component {
  constructor(props) {
    super(props);

    const note = getNote(props.id);

    this.state = {
      note
    };

    this.onDelete = this.onDelete.bind(this);
    this.onArchiveToggle = this.onArchiveToggle.bind(this);
  }

  onDelete() {
    if (this.state.note) {
      deleteNote(this.state.note.id);
      this.props.navigate(this.state.note.archived ? '/archives' : '/');
    }
  }

  onArchiveToggle() {
    if (!this.state.note) return;

    if (this.state.note.archived) {
      unarchiveNote(this.state.note.id);
      this.props.navigate('/'); 
    } else {
      archiveNote(this.state.note.id);
      this.props.navigate('/archives');
    }
  }

  render() {
    if (this.state.note === undefined || this.state.note === null) {
      return (
        <section className="detail-page">
          <h3 className="detail-page__title">Catatan tidak ditemukan</h3>
        </section>
      );
    }

    const isArchived = this.state.note.archived;

    return (
      <>
        <NoteDetail {...this.state.note} />

        <div className="detail-page__action">
          <NoteItemAction
            title={isArchived ? 'Batal Arsip' : 'Arsipkan'}
            ariaLabel={isArchived ? 'Batal Arsip' : 'Arsipkan'}
            onClick={this.onArchiveToggle}
          />
          <NoteItemAction title="Hapus" onClick={this.onDelete} />
        </div>
      </>
    );
  }
}

export default DetailPageWrapper;