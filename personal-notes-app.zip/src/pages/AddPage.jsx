import React from 'react';
import { useNavigate } from 'react-router-dom';
import NoteInput from '../components/NoteInput';
import NoteItemAction from '../components/NoteItemAction';
import { addNote } from '../utils/local-data';

function AddPageWrapper() {
  const navigate = useNavigate();

  function onAddNote({ title, body }) {
    addNote({ title, body });
    navigate('/');
  }

  return <AddPage addNote={onAddNote} />;
}

class AddPage extends React.Component {
  constructor(props) {
    super(props);

    this.formRef = React.createRef();
    this.submit = this.submit.bind(this);
  }

  submit() {
    if (this.formRef.current) {
      const evt = new Event('submit', { bubbles: true, cancelable: true });
      this.formRef.current.dispatchEvent(evt);
    }
  }

  render() {
    return (
      <>
        <section className="add-new-page">
          <NoteInput addNote={this.props.addNote} refCallback={(el) => (this.formRef.current = el)} />
        </section>

        <div className="add-new-page__action">
          <NoteItemAction title="Simpan" onClick={() => this.submit()} />
        </div>
      </>
    );
  }
}

export default AddPageWrapper;